# Rasmus Bundgaard-Nielsen
# 18-04-2020
# Datalogger opgave
# Laver eller overskriver en fil med navn PiDataLog.csv i mappen hvorfra koden køres
# som logger dato, tiden, temperaturen, trykket, fugtigheden hvert 10 sek


import time # import af time så jeg kan bruge sleep
import datetime #import af dato/tid så jeg kan timestamp mine data
from sense_hat import SenseHat
sense = SenseHat()

myFile=open('PiDataLog.csv', 'w') #Laver / overskriver en fil med navnet
myFile.write("date,time,temp(C),pressure(mbar),rh(%)\n") #laver en header så data kan identificeres senere
myFile.close() #lukker filen

while True:
    x = datetime.datetime.now() #Hvad er tiden nu
    t=sense.get_temperature() #Hvad er temperaturen
    p=sense.get_pressure() #Hvad er trykket
    h=sense.get_humidity() #Hvad er luftfugtigheden

    myFile=open('PiDataLog.csv', 'a') #åbner filen i append mode, dvs begynder at skrive videre i filen
    myFile.write(x.strftime("%Y/%m/%d,%X")) #skriver dato og tid ind YYYY/MM/DD,hh:mm:ss
    myFile.write(",%.0f" %t + ",%.0f" %p + ",%.0f\n" %h) #skriver mine målinger ,temp,tryk,fugtighed og derefter en ny linje
    myFile.close() #lukker filen igen

    
    time.sleep(10) #hvor ofte der skal laves en måling, her hver 10sek
          
