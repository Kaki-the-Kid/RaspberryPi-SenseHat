#/bin/python3.7
print("Skriv dit navn: ")

navn = input()

print("Indtast din alder: ")

alder = input()

print(navn + " er " + alder + " gammel.")
