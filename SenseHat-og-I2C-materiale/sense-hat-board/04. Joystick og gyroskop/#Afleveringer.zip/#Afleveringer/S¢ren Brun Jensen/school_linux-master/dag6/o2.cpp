#include <iostream>

int main(){

std::string name;
int age;

std::cout << "Enter your name: " <<std::endl;
std::cin >> name;
std::cout << "\nEnter your age: " << std::endl;
std::cin >> age;
std::cout << "Hey " << age << " year old " << name << std::endl;
}
