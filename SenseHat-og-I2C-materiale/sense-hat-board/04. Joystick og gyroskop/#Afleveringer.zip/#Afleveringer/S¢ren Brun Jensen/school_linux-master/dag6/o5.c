#include <stdio.h>

int main(){
float pi = 3.1415926536;
float sqrt2 = 1.41421356237;

printf("%.3f\n", pi);
printf("%.2f\n", sqrt2);
}
